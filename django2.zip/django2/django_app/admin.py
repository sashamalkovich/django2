from django.contrib import admin

# Register your models here.
from django_app.models import Article

admin.site.register(Article)

